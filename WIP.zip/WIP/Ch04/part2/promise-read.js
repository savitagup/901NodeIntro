const Promise = require("bluebird");
const fs = Promise.promisifyAll(require("fs"));

Promise.try(()=>{
    return fs.readFileSync('input.txt')
}).then((data => {
    console.log(data.toString());
})).catch((err)=>{
    console.log(err);
});

console.log('ended');