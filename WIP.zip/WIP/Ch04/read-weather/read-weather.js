//const weather = require('./weather.json');
var fs = require("fs");

// Asynchronous read
fs.readFile('weather.json', function (err, data) {
   if (err) {
      return console.error(err);
   }
   const weatherArray = JSON.parse(data);
   console.log("Asynchronous read: " + weatherArray.forEach(element => {
       console.log(element.day);
   
})
);
});
console.log('End of program file');