function Person(firstName, lastName){
    this.firstName = firstName;
    this.lastName = lastName;

    this.getFullName = function (){
        return `${firstName} ${lastName}`;
    }

}
let person1 = new Person('first','last');
console.log(person1.getFullName());