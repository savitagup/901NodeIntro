const weatherArray = [
    {
    day : "Monday",
    high : 80,
    low : 75
    },
    {
    day : "Tuesday",
    high : 60,
    low : 58
    },
    {
    day : "Wednesday",
    high : 70,
    low : 65
    }
];


let lowestDay = weatherArray[0];
let highestDay = weatherArray[0];

weatherArray.forEach(element => {
     if (lowestDay.low > element.low) {
         lowestDay = element;
     }

    if (highestDay.high < element.high) {
        highestDay = element;
    }
});

console.log (`The lowest temperature this week was on ${lowestDay.day} and it was ${lowestDay.low}`);


console.log (`The highest temperature this week was on ${highestDay.day} and it was ${highestDay.high}`);


