let firstName = 'First';
let lastName = 'Last';
console.log(`Hello ${firstName} ${lastName}`);
