let roundUp= 1.5;
let rounded = Math.round(roundUp);
console.log(rounded);