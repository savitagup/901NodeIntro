function math (first, second, third){
    return first + (second * third);
};

console.log(math(53,61,67));