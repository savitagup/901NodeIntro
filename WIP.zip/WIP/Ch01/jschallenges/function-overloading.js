let testArray = [7,9,0,-2];
let emptyArray = [];
function first(array, nElements ){
    if(nElements){
        if(nElements>0) {
        return array.slice(0,nElements);
    } else {
        return emptyArray;
    }

    }
    return array[0];
};

console.log(first(testArray)); 
console.log(first(emptyArray,3)); 
console.log(first(testArray,3)); 
console.log(first(testArray,6)); 
console.log(first(testArray,-3));
