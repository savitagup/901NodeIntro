const http = require('http');
const Promise = require("bluebird");

const server = http.createServer();
var fs = Promise.promisifyAll(require("fs"));

// Asynchronous read
// let weatherArray = [] ;
// weatherArray = fs.readFile('weather.json', function (err, data) {
//     if (err) {
//        return console.error(err);
//     }
//     return JSON.parse(data);


//  });
//  console.log(weatherArray);
// server.on('request', (request, response) => {
//     console.log(weatherArray.toString);

//     response.end(`Hello ` +weatherArray.toString);
// });

// server.listen(3133, (err) => {  
//     if (err) {
//         return console.log('something bad happened', err);
//     }

//     console.log(`server is listening on http://localhost:3133`);
//     })



// Promise.try(() => {
// 	return fs.readFileAsync("./input.txt");
// }).then((fileContents) => {
// 	console.log(fileContents.toString());
// }).catch((err) => {
// 	console.error("An error occurred", err);
// });



Promise.try(() => {
    return fs.readFileSync('weather.json')
    //         weather = JSON.parse(data);
    //         console.log('weather' +weather);
    // //        return weather;

}).then(weatherArray => {
    console.log('inside' + weatherArray);

    server.on('request', (request, response) => {

        response.end(`Hello ` + weatherArray);
    })
}).then(() => {

    server.listen(3133, (err) => {
        if (err) {
            return console.log('something bad happened', err);
        }

        console.log(`server is listening on http://localhost:3133`);
    })
}).catch((err) => {
    console.log(err);
})
