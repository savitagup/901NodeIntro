

const Promise = require("bluebird");
const knex = require("knex");
let db = knex(require("./knexfile"));

Promise.try(() => {
	return db("customer");
}).then((customer) => {
	console.log("All the people:", customer);
}).finally(() => {
	db.destroy();
});
