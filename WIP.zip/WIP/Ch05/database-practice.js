const Promise = require("bluebird");
const knex = require("knex");
let db = knex(require("./knexfile"));

Promise.try(() => {
	return db.schema.createTable("customer", (table) => {
		table.increments("id").primary();
		table.text("firstName");
		table.text("lastName");
		table.text("email");
	});
}).then(() => {return db("customer").insert([{
    firstName: "Joe",
    lastName: "Bloggs",
    email: "abc@yahoo.com"
}, {
    firstName: "Joe",
    lastName: "Smith",
    email: "abc1@yahoo.com"
}]);
}).then(() => {
    return db("customer");
}).then((customer) => {
	console.log("All the customers:", customer);
}).finally(() => {
	db.destroy();
});


