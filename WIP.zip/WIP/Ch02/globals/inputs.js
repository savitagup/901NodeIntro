console.log(`current filename is ${__filename}`);
console.log(`current dirname is ${__dirname}`);
console.log(`First argument of process is ${process.argv[0]}`);
console.log(`Second argument of process is ${process.argv[1]}`);