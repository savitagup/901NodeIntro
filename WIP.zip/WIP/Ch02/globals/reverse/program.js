 


 function rev(val){
       
        return val.split("").reverse().join("");
    }
 
    // function upperCase(val1){
    //     val1 = val1.slice(2);
    //    let words = val1.split(" ");
    //    console.log(words);
    //    words.forEach(element => {
    //     element.charAt(0).toLocaleUpperCase();
    //     //element =  element.split("")[0].toLocaleUpperCase();
    //    });
    //    console.log(words);

    //     return words.join(" ");
    // }
    module.exports = rev;
 //   module.exports = upperCase;
