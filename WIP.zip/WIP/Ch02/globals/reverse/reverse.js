const rev = require('./program');
//const upperCase = require('./program');
console.log(' Reverse of the string is ' +rev(process.argv[2]));
//console.log(' Reverse of the string is ' +upperCase(process.argv));