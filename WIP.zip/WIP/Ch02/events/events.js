// Import events module
var events = require('events');

// Create an eventEmitter object
var eventEmitter = new events.EventEmitter();

// Create an event handler as follows
var workHandler = function workNow() {
   console.log('Write Tests');
   console.log('Code');
   console.log('Refactor');
   console.log('Go to Meeting');
   console.log('***********');

}

var breakHandler = function workNow() {
    console.log('Break Time****Check Emails**********');
  
 }
// Bind the connection event with the handler
eventEmitter.once('work', function(){
    console.log('Clocking in')
});

eventEmitter.on('work', workHandler);
eventEmitter.on('break', breakHandler);

// Bind the data_received event with the anonymous function
eventEmitter.on('data_received', function(){
   console.log('data received succesfully.');
});

// Fire the connection event 
eventEmitter.emit('work' );
eventEmitter.emit('work' );
eventEmitter.emit('break');
eventEmitter.emit('work' );

console.log("Program Ended.");