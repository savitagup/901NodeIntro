module.exports = class Calculator {
    add(a,b){
        return a+b;
    }

    subtract(a,b){
        return a-b;
    }
    
    multily(a,b){
        return a * b;
    }
    
    areacircle(radius){
        return 3.14 * radius * radius;
    }

    
    areaSquare(side){
        return side * side;
    }

    areaTriangle(base, height){
        return 1/2 * base * height;
    }

}