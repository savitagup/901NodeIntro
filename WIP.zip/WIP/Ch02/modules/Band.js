

    // function Band(name, memberArray){
    //     this.name = name;
    //     this.members = memberArray;
    // }

    // Band.prototype.memberCount = function() {
    //     return this.members.length;
    // }
    // Band.prototype.hasMember = function(name){
    //     return this.members.includes(name);
    // }

    class Band {
        constructor(name, memberArray){
        this.name = name;
        this.members = memberArray;
        }

    memberCount() {
        return this.members.length;
    }
    hasMember(name){
        return this.members.includes(name);
    }
    
}
    module.exports = Band;