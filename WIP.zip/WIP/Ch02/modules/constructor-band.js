const Band = require('./Band');

Band.prototype.memberCount = function() {
    return this.members.length;
}
Band.prototype.hasMember = function(name){
    return this.members.prototype.hasMember(name);
}