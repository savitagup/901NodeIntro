const Band = require('./Band');
const beatles = new Band('The Beatles', ['John', 'Paul', 'George', 'Ringo']);
console.log(`Beatles member count ` , beatles.memberCount());
console.log(`Beatles member Present ` , beatles.hasMember('George'));
