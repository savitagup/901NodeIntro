const Calculator = require('./calculator');
const calc =  new Calculator();
console.log(`Area of a square ` , calc.areaSquare(4));
//console.log(`Beatles member Present ` , beatles.hasMember('George'));
console.log(`Area of a circle ` , calc.areacircle(4));
console.log(`Area of a Triangle ` , calc.areaTriangle(4,5));

 