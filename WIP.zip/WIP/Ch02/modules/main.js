const Calculator = require('./calculator');
const myCalc = new Calculator();
//const add = require('./add.js');
console.log(`5 + 2 =`,myCalc.add(5,2));
console.log(`5 - 2 =`,myCalc.subtract(5,2));
console.log(`5 + 2 =`,myCalc.multily(5,2));

