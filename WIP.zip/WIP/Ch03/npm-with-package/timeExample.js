let moment = require('moment');
var momentTZ = require('moment-timezone');

console.log(moment().format('MM-DD-YYYY'));
console.log(moment("20110101","YYYYMMDD").fromNow());

var est = momentTZ().tz("America/New_York").format('ha z');

//var pst = moment(new Date(),'America/Los_Angeles' );
var pst = momentTZ().tz("America/Los_Angeles").format('ha z');
//var pst = moment().format(new Date(),'America/Los_Angeles');
console.log('It is now ' + est + ' and ' + pst +' Pacific');