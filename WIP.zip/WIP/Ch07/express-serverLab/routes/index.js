const express = require("express");
const moment = require('moment');
let router = express.Router();
const studentArray = require('./studentArray');

router.get("/", (req,res) => {
    res.render('index', {
        students : studentArray
    });
});

router.get("/about", (req, res) => {
	res.render("about");
});

router.get("/class", (req, res) => {
    res.render('class', {
        students : studentArray
    });
//	res.render("class");
});

// router.get("/", (req,res) => {
//     res.send("Hello World")
// });

// router.get("/about", (req,res) => {
//     res.send("Hello World from about page")
// });

// router.get("/class", (req,res) => {
//     res.send("Welcome to the class page")
// });

// router.get("/weather", (req,res) => {
//     res.send(`Welcome to the weather page   
//             Today's high temp is ${Math.random()}`);

// });

// router.get("/fromDB", (req,res) => {
//     var data = getDataFromDB();
//     console.log('index'+data);
//     res.send(`Welcome to the DB page ${data}`);

// });

// function getDataFromDB(){
//     var val = [];
//     Promise.try(() => {
//         return db("people");
//     }).then((people) => {
//         console.log("All the people:", people);
//         val = people;
//         //return people;
//     }).finally(() => {
//         db.destroy();
//     });
//     console.log(val);
//     return val;
// }
module.exports = router;