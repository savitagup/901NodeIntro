const express = require('express');
const path = require('path');

let app = express();
const config = require("./config.json");
app.use(require('./routes/index'));
app.set('views', path.join(__dirname,'views'));
app.set('view engine' , 'pug');

app.use(express.static(path.join(__dirname, "public")));

app.listen(config.port, ()=>{
    console.log(`Listening to port ${config.port} `);
});

