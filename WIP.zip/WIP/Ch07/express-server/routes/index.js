const express = require("express");
let router = express.Router();
    
const Promise = require("bluebird");
const knex = require("knex");
let db = knex(require("./knexfile"));

router.get("/", (req,res) => {
    res.send("Hello World")
});

router.get("/about", (req,res) => {
    res.send("Hello World from about page")
});

router.get("/class", (req,res) => {
    res.send("Welcome to the class page")
});

router.get("/weather", (req,res) => {
    res.send(`Welcome to the weather page   
            Today's high temp is ${Math.random()}`);

});


router.get("/fromDB", (req,res) => {

Promise.try(() => {
    return db("people")
    .select([
		"people.id"
	]);
}).each((item) => {
    res.send(`${item.id})`);
	//console.log(`${item.id})`)
}).finally(() => {
	db.destroy();
});
});

// router.get("/fromDB", (req,res) => {
//     // var data = getDataFromDB();
//     // console.log('index'+data);
//     // res.send(`Welcome to the DB page ${data}`);

//     Promise.try(() => {
//         return db("people");
//     }).then((people) => {
//         console.log("All the people:", people);
//         console.log(typeof(people));
//       //  var data = people.firstName
      
//         res.send(`Welcome to the DB page ${people.firstName}`);
//         //val = 'abc';//people;
//         //return people;
//     }).finally(() => {
//         db.destroy();
//     });

//});

function getDataFromDB(){
    var val = [];
    Promise.try(() => {
        return db("people");
    }).then((people) => {
        console.log("All the people:", people);
        val = 'abc';//people;
        //return people;
    }).finally(() => {
        db.destroy();
    });
    console.log(val);
    return val;
}
module.exports = router;