const express = require('express');
let app = express();
const config = require("./config.json");
app.use(require('./routes/index'));

app.listen(config.port, ()=>{
    console.log(`Listening to port ${config.port} `);
});

